#

import copy
import problema_espacio_estados as probee
import búsqueda_espacio_estados as busqueda

##############Colocamos la I horizontal
"""
class ponerIHorizontal(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la I en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_IHorizontal(self, estado):
        res = []
        i=1

        if (i- estado[self.fila][self.columna]) == i:
            res.append(True)
        else:
            res.append(False)


        if i - estado[self.fila][self.columna - 1]== i:
            res.append(True)
        else:
            res.append(False)

        if i -  estado[self.fila][self.columna - 2] == i:
            res.append(True)
        else:
            res.append(False)

        if i - estado[self.fila][self.columna - 3] == i:
            res.append(True)
        else:
            res.append(False)

        if i - estado[self.fila][self.columna - 4] == i:
            res.append(True)
        else:
            res.append(False)

        if res.count(False) > 0:
            return False
        else:
            return True


    def es_aplicable(self, estado):

        if(self.columna >= 4 and self.columna < len(estado[0]) and self.fila >= 0 and self.fila < len(estado)):

             if (self.hay_hueco_IHorizontal(estado)):  # == True):
                    return True
             else:
                    return False

    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 1
        nuevo_estado[self.fila][self.columna -1] = 1
        nuevo_estado[self.fila][self.columna -2] = 1
        nuevo_estado[self.fila][self.columna - 3] = 1
        nuevo_estado[self.fila][self.columna - 4] = 1
        return nuevo_estado





############Colocamos la V normal

class ponerV(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la V en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_V(self, estado):

      res = []
      v=39

      if v -  estado[self.fila][self.columna] == v:
            res.append(True)
      else:
            res.append(False)
      if v - estado[self.fila][self.columna-1] == v:
            res.append(True)
      else:
            res.append(False)

      if v- estado[self.fila][self.columna-2] == v:
            res.append(True)
      else:
            res.append(False)

      if v- estado[self.fila-1][self.columna -2] ==v:
            res.append(True)
      else:
            res.append(False)

      if v - estado[self.fila-2][self.columna -2] == v:
            res.append(True)
      else:
            res.append(False)

      if res.count(False) > 0:
        return False
      else:
        return True


    def es_aplicable(self, estado):

        if self.columna >= 2 and self.columna < len(estado[0]) and self.fila >= 2 and self.fila < len(estado):

            if (self.hay_hueco_V(estado)):
                return True
            else:
                return False

    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 39
        nuevo_estado[self.fila][self.columna -1] = 39
        nuevo_estado[self.fila][self.columna - 2] = 39
        nuevo_estado[self.fila-1][self.columna-2] = 39
        nuevo_estado[self.fila -2][self.columna-2] = 39
        return nuevo_estado



############Poner V2

class ponerV2(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la V2 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_V2(self, estado):
        res = []
        v=40
        if v - estado[self.columna][self.fila] == v:
            res.append(True)
        else:
            res.append(False)
        if v - estado[self.fila][self.columna+1] == v:
            res.append(True)
        else:
            res.append(False)

        if v- estado[self.fila][self.columna+2] == v:
            res.append(True)
        else:
            res.append(False)

        if v- estado[self.fila-1][self.columna+2] == v:
            res.append(True)
        else:
            res.append(False)

        if v- estado[self.fila-2][self.columna+2]== v:
            res.append(True)
        else:
            res.append(False)


        if res.count(False) > 0:
            return False
        else:
            return True


    def es_aplicable(self, estado):

        if self.columna >= 2 and self.columna < len(estado[0]) and self.fila >= 2 and self.fila < len(estado):
            if (self.hay_hueco_V2(estado)):
                return True
            else:
                return False

    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 40
        nuevo_estado[self.fila][self.columna+1] = 40
        nuevo_estado[self.fila][self.columna+2] = 40
        nuevo_estado[self.fila-1][self.columna +2] = 40
        nuevo_estado[self.fila-2][self.columna +2] = 40
        return nuevo_estado





############Poner V3

class ponerV3(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la V3 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_V3(self, estado):

        res = []
        v3=41

        if v3- estado[self.columna][self.fila] == v3:
                    res.append(True)
        else:
                    res.append(False)

        if v3 -  estado[self.fila-1][self.columna] == v3:
                    res.append(True)
        else:
                    res.append(False)
        if  v3 - estado[self.fila-2][self.columna] == v3:
                    res.append(True)
        else:
                    res.append(False)

        if v3 -  estado[self.fila-2][self.columna -1] == v3:
                    res.append(True)
        else:
                    res.append(False)

        if  v3 - estado[self.fila-2][self.columna - 2]== v3:
                    res.append(True)
        else:
                    res.append(False)
        if res.count(False) > 0:
                return False
        else:
                return True



    def es_aplicable(self, estado):

        if self.columna >= 2 and self.columna < len(estado[0]) and self.fila >= 2 and self.fila < len(estado):
            if (self.hay_hueco_V3(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 41
        nuevo_estado[self.fila-1][self.columna] = 41
        nuevo_estado[self.fila-2][self.columna] = 41
        nuevo_estado[self.fila-2][self.columna-1] = 41
        nuevo_estado[self.fila-2][self.columna-2] = 41
        return nuevo_estado



############Poner V4

class ponerV4(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la V4 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_V4(self, estado):

        res = []
        v4=42

        if v4- estado[self.columna][self.fila] == v4:
                    res.append(True)
        else:
                    res.append(False)

        if v4 -  estado[self.fila][self.columna-1] == v4:
                    res.append(True)
        else:
                    res.append(False)
        if  v4 - estado[self.fila][self.columna-2] == v4:
                    res.append(True)
        else:
                    res.append(False)

        if v4 -  estado[self.fila+2][self.columna -2] == v4:
                    res.append(True)
        else:
                    res.append(False)

        if  v4 - estado[self.fila+1][self.columna -2]== v4:
                    res.append(True)
        else:
                    res.append(False)
        if res.count(False) > 0:
                return False
        else:
                return True



    def es_aplicable(self, estado):

        if self.columna >= 2 and self.columna < len(estado[0]) and self.fila >= 0 and self.fila < len(estado)-2:
            if (self.hay_hueco_V4(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 42
        nuevo_estado[self.fila][self.columna-1] = 42
        nuevo_estado[self.fila][self.columna-2] = 42
        nuevo_estado[self.fila+1][self.columna-2] = 42
        nuevo_estado[self.fila+2][self.columna-2] = 42
        return nuevo_estado


############Poner U

class ponerU(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la U en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_U(self, estado):

        res = []
        u=43

        if u- estado[self.columna][self.fila] == u:
                    res.append(True)
        else:
                    res.append(False)

        if u -  estado[self.fila][self.columna-1] == u:
                    res.append(True)
        else:
                    res.append(False)
        if  u - estado[self.fila][self.columna+1] == u:
                    res.append(True)
        else:
                    res.append(False)

        if u -  estado[self.fila-1][self.columna+1] == u:
                    res.append(True)
        else:
                    res.append(False)

        if  u - estado[self.fila-1][self.columna -1]== u:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True



    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0])-1 and self.fila >= 1 and self.fila < len(estado):
            if (self.hay_hueco_U(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 43
        nuevo_estado[self.fila][self.columna-1] = 43
        nuevo_estado[self.fila][self.columna+1] = 43
        nuevo_estado[self.fila-1][self.columna-1] = 43
        nuevo_estado[self.fila-1][self.columna+1] = 43
        return nuevo_estado



############Poner U2

class ponerU2(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la U2 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_U2(self, estado):

        res = []
        u=44

        if u- estado[self.columna][self.fila] == u:
                    res.append(True)
        else:
                    res.append(False)

        if u -  estado[self.fila-1][self.columna] == u:
                    res.append(True)
        else:
                    res.append(False)
        if  u - estado[self.fila-2][self.columna] == u:
                    res.append(True)
        else:
                    res.append(False)

        if u -  estado[self.fila][self.columna-1] == u:
                    res.append(True)
        else:
                    res.append(False)

        if  u - estado[self.fila-2][self.columna -1]== u:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True



    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0]) and self.fila >= 2 and self.fila < len(estado):
            if (self.hay_hueco_U2(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 44
        nuevo_estado[self.fila-1][self.columna] = 44
        nuevo_estado[self.fila-2][self.columna] = 44
        nuevo_estado[self.fila-2][self.columna-1] = 44
        nuevo_estado[self.fila][self.columna-1] = 44
        return nuevo_estado



############Poner U3

class ponerU3(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la U3 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_U3(self, estado):

        res = []
        u=45

        if u- estado[self.columna][self.fila] == u:
                    res.append(True)
        else:
                    res.append(False)

        if u -  estado[self.fila][self.columna-1] == u:
                    res.append(True)
        else:
                    res.append(False)
        if  u - estado[self.fila][self.columna+1] == u:
                    res.append(True)
        else:
                    res.append(False)

        if u -  estado[self.fila+1][self.columna-1] == u:
                    res.append(True)
        else:
                    res.append(False)

        if  u - estado[self.fila+1][self.columna +1]== u:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True



    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0])-1 and self.fila >= 0 and self.fila < len(estado)-1:
            if (self.hay_hueco_U3(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 45
        nuevo_estado[self.fila+1][self.columna+1] = 45
        nuevo_estado[self.fila+1][self.columna-1] = 45
        nuevo_estado[self.fila][self.columna+1] = 45
        nuevo_estado[self.fila][self.columna-1] = 45
        return nuevo_estado



############Poner U4

class ponerU4(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la U4 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_U4(self, estado):

        res = []
        u=46

        if u- estado[self.columna][self.fila] == u:

                    res.append(True)
        else:
                    res.append(False)

        if u -  estado[self.fila-1][self.columna] == u:
                    res.append(True)
        else:
                    res.append(False)
        if  u - estado[self.fila-1][self.columna+1] == u:
                    res.append(True)
        else:
                    res.append(False)

        if u -  estado[self.fila+1][self.columna] == u:
                    res.append(True)
        else:
                    res.append(False)

        if  u - estado[self.fila+1][self.columna +1]== u:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True



    def es_aplicable(self, estado):

        if self.columna >= 0 and self.columna < len(estado[0])-2 and self.fila >=0 and self.fila < len(estado)-2:
            if (self.hay_hueco_U4(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 46
        nuevo_estado[self.fila-1][self.columna] = 46
        nuevo_estado[self.fila-1][self.columna+1] = 46
        nuevo_estado[self.fila+1][self.columna] = 46
        nuevo_estado[self.fila+1][self.columna+1] = 46
        return nuevo_estado


############Poner W

class ponerW(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la W en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_W(self, estado):

        res = []
        w=47

        if w- estado[self.columna][self.fila] == w:
                    res.append(True)
        else:
                    res.append(False)

        if w -  estado[self.fila][self.columna-1] == w:
                    res.append(True)
        else:
                    res.append(False)
        if  w - estado[self.fila-1][self.columna-1] == w:
                    res.append(True)
        else:
                    res.append(False)

        if w -  estado[self.fila+1][self.columna] == w:
                    res.append(True)
        else:
                    res.append(False)

        if  w - estado[self.fila+1][self.columna+1]== w:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0])-1 and self.fila >= 1 and self.fila < len(estado)-1:
            if (self.hay_hueco_W(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 47
        nuevo_estado[self.fila][self.columna-1] = 47
        nuevo_estado[self.fila-1][self.columna-1] = 47
        nuevo_estado[self.fila+1][self.columna] = 47
        nuevo_estado[self.fila+1][self.columna+1] = 47
        return nuevo_estado


class ponerW2(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la W2 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_W2(self, estado):

        res = []
        w=48

        if w- estado[self.columna][self.fila] == w:
                    res.append(True)
        else:
                    res.append(False)

        if w -  estado[self.fila][self.columna+1] == w:
                    res.append(True)
        else:
                    res.append(False)
        if  w - estado[self.fila-1][self.columna+1] == w:
                    res.append(True)
        else:
                    res.append(False)

        if w -  estado[self.fila+1][self.columna] == w:
                    res.append(True)
        else:
                    res.append(False)

        if  w - estado[self.fila+1][self.columna-1]== w:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0])-1 and self.fila >= 1 and self.fila < len(estado)-1:
            if (self.hay_hueco_W2(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 48
        nuevo_estado[self.fila][self.columna+1] = 48
        nuevo_estado[self.fila-1][self.columna+1] = 48
        nuevo_estado[self.fila+1][self.columna] = 48
        nuevo_estado[self.fila+1][self.columna-1] = 48
        return nuevo_estado

class ponerW3(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la W2 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_W3(self, estado):

        res = []
        w=49

        if w- estado[self.columna][self.fila] == w:
                    res.append(True)
        else:
                    res.append(False)

        if w -  estado[self.fila][self.columna+1] == w:
                    res.append(True)
        else:
                    res.append(False)
        if  w - estado[self.fila+1][self.columna+1] == w:
                    res.append(True)
        else:
                    res.append(False)

        if w -  estado[self.fila-1][self.columna] == w:
                    res.append(True)
        else:
                    res.append(False)

        if  w - estado[self.fila-1][self.columna-1]== w:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0])-1 and self.fila >= 1 and self.fila < len(estado)-1:
            if (self.hay_hueco_W3(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 49
        nuevo_estado[self.fila][self.columna+1] = 49
        nuevo_estado[self.fila+1][self.columna+1] = 49
        nuevo_estado[self.fila-1][self.columna-1] = 49
        nuevo_estado[self.fila][self.columna-1] = 49
        return nuevo_estado

class ponerW4(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la W2 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_W4(self, estado):

        res = []
        w=50

        if w- estado[self.columna][self.fila] == w:
                    res.append(True)
        else:
                    res.append(False)

        if w -  estado[self.fila-1][self.columna] == w:
                    res.append(True)
        else:
                    res.append(False)
        if  w - estado[self.fila-1][self.columna+1] == w:
                    res.append(True)
        else:
                    res.append(False)

        if w -  estado[self.fila+1][self.columna-1] == w:
                    res.append(True)
        else:
                    res.append(False)

        if  w - estado[self.fila][self.columna-1]== w:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0])-1 and self.fila >= 1 and self.fila < len(estado)-1:
            if (self.hay_hueco_W4(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 50
        nuevo_estado[self.fila-1][self.columna] = 50
        nuevo_estado[self.fila-1][self.columna+1] = 50
        nuevo_estado[self.fila+1][self.columna-1] = 50
        nuevo_estado[self.fila][self.columna-1] = 50
        return nuevo_estado

class ponerX(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la W2 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_X(self, estado):

        res = []
        x=51

        if x- estado[self.columna][self.fila] == x:
                    res.append(True)
        else:
                    res.append(False)

        if x -  estado[self.fila-1][self.columna] == x:
                    res.append(True)
        else:
                    res.append(False)
        if  x - estado[self.fila+1][self.columna] == x:
                    res.append(True)
        else:
                    res.append(False)

        if x -  estado[self.fila][self.columna-1] == x:
                    res.append(True)
        else:
                    res.append(False)

        if  x - estado[self.fila][self.columna+1]== x:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0])-1 and self.fila >= 1 and self.fila < len(estado)-1:
            if (self.hay_hueco_X(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 51
        nuevo_estado[self.fila-1][self.columna] = 51
        nuevo_estado[self.fila+1][self.columna] = 51
        nuevo_estado[self.fila][self.columna+1] = 51
        nuevo_estado[self.fila][self.columna-1] = 51
        return nuevo_estado


class ponerY(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la W2 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_Y(self, estado):

        res = []
        y=52

        if y- estado[self.columna][self.fila] == y:
                    res.append(True)
        else:
                    res.append(False)

        if y -  estado[self.fila-1][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)
        if  y - estado[self.fila-2][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)

        if y -  estado[self.fila-2][self.columna-1] == y:
                    res.append(True)
        else:
                    res.append(False)

        if  y - estado[self.fila-3][self.columna]== y:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0]) and self.fila >= 3 and self.fila < len(estado):
            if (self.hay_hueco_Y(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 52
        nuevo_estado[self.fila-1][self.columna] = 52
        nuevo_estado[self.fila-2][self.columna] = 52
        nuevo_estado[self.fila-2][self.columna-1] = 52
        nuevo_estado[self.fila-3][self.columna] = 52
        return nuevo_estado



class ponerY2(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la Y2 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_Y2(self, estado):

        res = []
        y=53

        if y- estado[self.columna][self.fila] == y:
                    res.append(True)
        else:
                    res.append(False)

        if y -  estado[self.fila-1][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)
        if  y - estado[self.fila-2][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)

        if y -  estado[self.fila-3][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)

        if  y - estado[self.fila-2][self.columna+1]== y:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 0 and self.columna < len(estado[0])-1 and self.fila >= 3 and self.fila < len(estado):
            if (self.hay_hueco_Y2(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 53
        nuevo_estado[self.fila-1][self.columna] = 53
        nuevo_estado[self.fila-2][self.columna] = 53
        nuevo_estado[self.fila-3][self.columna] = 53
        nuevo_estado[self.fila-2][self.columna+1] = 53
        return nuevo_estado





class ponerY3(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la Y3 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_Y3(self, estado):

        res = []
        y=54

        if y- estado[self.columna][self.fila] == y:
                    res.append(True)
        else:
                    res.append(False)

        if y -  estado[self.fila-1][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)
        if  y - estado[self.fila-2][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)

        if y -  estado[self.fila+1][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)

        if  y - estado[self.fila][self.columna-1]== y:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 1 and self.columna < len(estado[0]) and self.fila >= 2 and self.fila < len(estado)-1:
            if (self.hay_hueco_Y3(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 54
        nuevo_estado[self.fila-1][self.columna] = 54
        nuevo_estado[self.fila-2][self.columna] = 54
        nuevo_estado[self.fila+1][self.columna] = 54
        nuevo_estado[self.fila][self.columna-1] = 54
        return nuevo_estado





class ponerY4(probee.Acción):
    def __init__(self, i, j):
        nombre = "Colocamos la Y4 en {} {}".format(i, j)
        super().__init__(nombre)
        self.fila = i
        self.columna = j

    def hay_hueco_Y4(self, estado):

        res = []
        y=55

        if y- estado[self.columna][self.fila] == y:
                    res.append(True)
        else:
                    res.append(False)

        if y -  estado[self.fila-1][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)
        if  y - estado[self.fila-2][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)

        if y -  estado[self.fila-3][self.columna] == y:
                    res.append(True)
        else:
                    res.append(False)

        if  y - estado[self.fila][self.columna+1]== y:
                    res.append(True)
        else:
                    res.append(False)

        if res.count(False) > 0:
                return False
        else:
                return True

    def es_aplicable(self, estado):

        if self.columna >= 0 and self.columna < len(estado[0])-1 and self.fila >= 3 and self.fila < len(estado):
            if (self.hay_hueco_Y4(estado)):
                return True
            else:
                return False


    def aplicar(self, estado):
        nuevo_estado = copy.deepcopy(estado)
        nuevo_estado[self.fila][self.columna] = 55
        nuevo_estado[self.fila-1][self.columna] = 55
        nuevo_estado[self.fila-2][self.columna] = 55
        nuevo_estado[self.fila-3][self.columna] = 55
        nuevo_estado[self.fila][self.columna+1] = 55
        return nuevo_estado








class Colocar(probee.ProblemaEspacioEstados):
    def __init__(self):
        acciones =[ponerIHorizontal(i,j) for i in range(0,5) for j in range(4,5)]+[ponerV(i,j) for i in range(2,5) for j in range(2,5)]+[ponerV2(i,j) for i in range(2,5) for j in range(0,3)]+[ponerV3(i,j) for i in range(2,5) for j in range(0,3)]+[ponerV4(i,j) for i in range(2,5) for j in range(0,3)]+[ponerU(i,j) for i in range (1,5) for j in range(1,4)]+[ponerU2(i,j) for i in range (2,5) for j in range(1,5)]+[ponerU3(i,j) for i in range (0,4) for j in range(1,4)]+[ponerU4(i,j) for i in range (1,4) for j in range(0,4)]+[ponerW(i,j) for i in range (1,4) for j in range(1,4)]+ [ponerW2(i,j) for i in range (1,4) for j in range(1,4)]+[ponerW3(i,j) for i in range (1,4) for j in range(1,4)]+[ponerW4(i,j) for i in range (1,4) for j in range(1,4)]+[ponerX(i,j) for i in range(1,4) for j in range(1,4)]+[ponerY(i,j) for i in range(3,5) for j in range(1,5)]+[ponerY2(i,j) for i in range(3,5) for j in range(0,4)]+[ponerY3(i,j) for i in range(2,4) for j in range(1,5)]#+[ponerY4(i,j) for i in range(3,5) for j in range(0,5)]
        estado_inicial = [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]]
        super().__init__(acciones, estado_inicial)

    def es_estado_final(self, estado):

        return sum(x == 0 for row in estado for x in row)<=4



colocar1 = Colocar()
b_anchura = busqueda.BúsquedaEnProfundidad(detallado=True)
b_anchura.buscar(colocar1)

"""