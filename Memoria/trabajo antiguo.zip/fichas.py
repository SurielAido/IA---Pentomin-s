class fichas:

    ficha_i = [[1],[1],[1],[1],[1]]

    ficha_f = [[0,2,2],[2,2,0],[0,2,0]]

    ficha_l = [[3,0],[3,0],[3,0],[3,3]]

    ficha_n = [[0,4],[4,4],[4,0],[4,0]]

    ficha_p = [[0,5],(5,5),(5,5)]

    ficha_t = [[6,6,6],[0,6,0],[0,6,0]]

    ficha_u = [[7,0,7],[7,7,7]]

    ficha_v = [[8,0,0],[8,0,0],[8,8,8]]

    ficha_w = [[9,0,0],[9,9,0],[0,9,9]]

    ficha_x = [[0,10,0],[10,10,10],[0,10,10]]

    ficha_y = [[0,11],[11,11],[0,11],[0,11]]

    ficha_z = [[12,12,0],[0,12,0],[0,12,12]]

    ficha={'i':ficha_i,'f':ficha_f,'l':ficha_l,'n':ficha_n,'p':ficha_p,'t':ficha_t,'u':ficha_u,'v':ficha_v,'w':ficha_w,'x':ficha_x,'y':ficha_y,'z':ficha_z}

    print(ficha.values);
    for i in range(0, 5):
        print(i)

def test():
    estado = [0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]
    for i in range(len(estado)):

        for j in range(len(estado[0])):
            print("i: ",i)
            print("j: ",j)
test()