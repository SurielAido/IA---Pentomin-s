#!/usr/bin/env python
# -*- coding: utf-8 -*-

import copy
from tablero import tablero
import búsqueda_espacio_estados as busqee
import problema_espacio_estados as probee
from fichas import fichas


#Necesitamos: Estado, Estado inicial, Estado final, Acciones.
f=input();
c=input();
estado = tablero.crear_tab();

class colocar_ficha(probee.Acción):
    def __init__(self):
        nombre = 'Colocar ficha'
        super().__init__(nombre)

    for i in ficha:
    estado[i] = ficha[i]

    def sitios_libres(estado): #incluir esto en cabe ficha.
        count = 0;
        count = False;
        for i in estado:
            for j in estado[i]:
                if estado[i][j] == 0:
                    count += 1;
        if count > 4:
            res = True
        return res

    fich = list(fichas.ficha.values())

    def cabe_ficha(estado): #Esta comprobación es errónea. La ficha siempre va a ser más pequeña que el tablero, equivalente a varilla
        fich = list(fichas.ficha.values())
        for i in fich:
            for j in fich[i]:
                if len(i) <= len(estado):
                    a = True
                else:
                    a = False
        return a;

    def es_aplicable(self, estado):
        return self.cabe_ficha(estado) and self.sitios_libres()

    def colocar_ficha(self,estado): #Rehacer con las fichas en la versión de código en lugar de la de fichero.
        res=[]
        archivo_fichas = open('fichas')
        for linea in archivo_fichas:
            linea = archivo_fichas.readline()
            for i in range(len(linea)):
                for j in range(len(linea[i])):
                    for k in range(len(estado)):
                        for l in range(len(estado)):
                            res[k][l] = linea[i][j] + tablero[k][l]
            return res;

    def aplicar(self):
        nuevo_estado = copy.deepcopy((estado))
        res = self.colocar_ficha(nuevo_estado)
        return res

estado_in = tablero.crear_tab();


#Contar con el tablero un max de 4 ceros.

def is_estado_final(estado):
    count = 0;
    for i in range(len(estado)):
        for j in range(len(estado[i])):
            if estado[i][j] == 0:
                count +=1;
    if count <= 4:
        print("Es final")
        return estado, True
    else:
        print("Es falso. Estado: ",estado)
        return False

