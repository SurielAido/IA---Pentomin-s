class tablero:

    def crear_tab(self):
        l=[]
        f = input("introduzca el n�mero de filas: ")
        c = input("Introduzca el n�mero de columas: ")
        for i in range (int(f)):
            l.append([])
            for j in range(int(c)):
                l[i].append(0)
        return l
